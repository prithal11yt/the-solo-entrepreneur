#!/usr/bin/env python3
"""Validate a Nick-style reel job and its beat sheet."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

DEFAULT_ENGINE = Path(__file__).resolve().parent.parent  # repo root
MEDIA_KEYS = {
    "src",
    "topSrc",
    "bottomSrc",
    "bgSrc",
    "media",
    "leftSrc",
    "rightSrc",
    "topSrc",
    "bottomSrc",
    "audio",
}
DISPLAY_TYPES = {"typecard", "wordcascade"}
FACE_TYPES = {"split", "footage", "wordcascade"}


def iter_media(value: Any, key: str | None = None):
    if isinstance(value, dict):
        for child_key, child in value.items():
            if child_key in MEDIA_KEYS and isinstance(child, str):
                yield child_key, child
            yield from iter_media(child, child_key)
    elif isinstance(value, list):
        for child in value:
            yield from iter_media(child, key)


def duration(path: Path) -> float | None:
    if not path.exists() or not shutil.which("ffprobe"):
        return None
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "csv=p=0",
            str(path),
        ],
        capture_output=True,
        text=True,
    )
    try:
        return float(result.stdout.strip())
    except ValueError:
        return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("slug")
    parser.add_argument(
        "--engine",
        type=Path,
        default=Path(os.environ.get("REEL_ENGINE", DEFAULT_ENGINE)),
    )
    args = parser.parse_args()
    slug = args.slug
    if not re.fullmatch(r"[a-z0-9-]+", slug):
        raise SystemExit("slug must use lowercase letters, numbers, and hyphens")

    engine = args.engine.expanduser().resolve()
    public = engine / "public"
    errors: list[str] = []
    warnings: list[str] = []

    required = {
        "brief": engine / f"jobs/{slug}/brief.json",
        "giveaway": engine / f"jobs/{slug}/giveaway.md",
        "script": engine / f"scripts/{slug}.md",
        "manifest": public / f"assets/{slug}/manifest.json",
        "beats": engine / f"src/beats/{slug}.json",
    }
    for label, path in required.items():
        if not path.exists():
            errors.append(f"missing {label}: {path}")
    if errors:
        print("\n".join(f"ERROR: {e}" for e in errors))
        raise SystemExit(1)

    brief = json.loads(required["brief"].read_text())
    manifest = json.loads(required["manifest"].read_text())
    beats = json.loads(required["beats"].read_text())

    if brief.get("style") != "nick-saraev":
        errors.append("brief style must be nick-saraev")
    if beats.get("id") != slug:
        errors.append(f"beat id must equal slug {slug!r}")
    for key, expected in (("fps", 30), ("width", 1080), ("height", 1920)):
        if beats.get(key) != expected:
            errors.append(f"{key} must be {expected}")
    if beats.get("captionStyle") != "chip-lg":
        errors.append("captionStyle must be chip-lg")

    scenes = beats.get("scenes")
    if not isinstance(scenes, list) or not scenes:
        errors.append("scenes must be a non-empty list")
        scenes = []
    captions = beats.get("captions")
    if not isinstance(captions, list) or not captions:
        errors.append("captions must be a non-empty list")

    total = 0.0
    for index, scene in enumerate(scenes):
        scene_type = scene.get("type", "")
        scene_duration = scene.get("durationSec")
        if not isinstance(scene_duration, (int, float)) or scene_duration <= 0:
            errors.append(f"scene {index}: invalid durationSec")
            continue
        total += float(scene_duration)
        if scene_duration > 4.2:
            warnings.append(
                f"scene {index} ({scene_type}) is {scene_duration:.2f}s; "
                "verify it moves internally"
            )
        if scene_type == "split" and scene.get("captionBottom", 0) < 900:
            errors.append(f"scene {index}: split captions must clear the face seam")
        if scene_type in DISPLAY_TYPES and scene.get("hideCaptions") is False:
            errors.append(f"scene {index}: display type cannot force captions on")

    if scenes:
        first = scenes[0]
        face_ok = first.get("type") in FACE_TYPES and (
            first.get("type") == "split"
            or "avatar" in str(first.get("src", "")).lower()
            or "avatar" in str(first.get("bottomSrc", "")).lower()
        )
        if not face_ok:
            errors.append("opening scene must visibly include the presenter")
        if first.get("durationSec", 0) > 2.8:
            warnings.append("opening face scene exceeds 2.8s")
        average = total / len(scenes)
        if average > 2.5:
            warnings.append(f"average scene duration {average:.2f}s exceeds 2.5s")
        for index in range(1, len(scenes)):
            if scenes[index - 1].get("type") == scenes[index].get("type"):
                warnings.append(
                    f"scenes {index - 1} and {index} repeat "
                    f"{scenes[index].get('type')} treatment"
                )

    music = beats.get("music")
    if not isinstance(music, dict) or not music.get("points"):
        errors.append("music bed with automation points is required")

    missing_media: set[str] = set()
    for _, media_path in iter_media(beats):
        if re.match(r"^https?://", media_path):
            continue
        local = public / media_path
        if not local.exists():
            missing_media.add(media_path)
    for media_path in sorted(missing_media):
        errors.append(f"missing public asset: {media_path}")

    audio_path = beats.get("audio")
    audio_duration = duration(public / audio_path) if isinstance(audio_path, str) else None
    if audio_duration is not None and abs(audio_duration - total) > 0.20:
        errors.append(
            f"scene duration {total:.2f}s differs from audio "
            f"{audio_duration:.2f}s by more than 0.20s"
        )

    items = manifest.get("items", [])
    if not isinstance(items, list) or not items:
        warnings.append("manifest contains no sourced assets")
    for index, item in enumerate(items if isinstance(items, list) else []):
        if item.get("kind") not in {"coded-graphic", "generated-illustration", "generated-video"}:
            if not item.get("source_url"):
                errors.append(f"manifest item {index} lacks source_url")
            if not item.get("credit"):
                warnings.append(f"manifest item {index} lacks on-screen credit")

    script_text = required["script"].read_text()
    keyword = str(brief.get("cta_keyword", ""))
    if keyword and keyword.lower() not in script_text.lower():
        errors.append(f"CTA keyword {keyword!r} is missing from the final script")
    if required["giveaway"].stat().st_size < 80:
        errors.append("giveaway resource is still a placeholder")

    print(f"job: {slug}")
    print(f"scenes: {len(scenes)}, total: {total:.2f}s")
    for warning in warnings:
        print(f"WARNING: {warning}")
    for error in errors:
        print(f"ERROR: {error}")
    if errors:
        raise SystemExit(1)
    print("validation passed")


if __name__ == "__main__":
    main()
