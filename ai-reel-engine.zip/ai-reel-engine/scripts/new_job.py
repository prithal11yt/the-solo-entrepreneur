#!/usr/bin/env python3
"""Initialize a Nick-style reel job without overwriting existing work."""

from __future__ import annotations

import argparse
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_ENGINE = Path(__file__).resolve().parent.parent  # repo root


def slugify(value: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return value[:64]


def write_new(path: Path, content: str) -> None:
    if path.exists():
        raise SystemExit(f"refusing to overwrite existing file: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("slug", nargs="?")
    parser.add_argument("--topic", required=True)
    parser.add_argument("--details", default="")
    parser.add_argument("--cta-keyword", default="")
    parser.add_argument("--target-seconds", type=int, default=38)
    parser.add_argument(
        "--engine",
        type=Path,
        default=Path(os.environ.get("REEL_ENGINE", DEFAULT_ENGINE)),
    )
    args = parser.parse_args()

    slug = slugify(args.slug or args.topic)
    if not slug:
        raise SystemExit("could not derive a safe slug")
    if not 26 <= args.target_seconds <= 48:
        raise SystemExit("--target-seconds must be between 26 and 48")

    engine = args.engine.expanduser().resolve()
    if not (engine / "package.json").exists():
        raise SystemExit(f"news-reels engine not found: {engine}")

    keyword = re.sub(r"[^A-Z0-9]", "", args.cta_keyword.upper())
    if not keyword:
        keyword = re.sub(r"[^A-Z0-9]", "", slug.split("-")[0].upper())[:14] or "GUIDE"

    brief = {
        "slug": slug,
        "topic": args.topic,
        "details": args.details,
        "style": "nick-saraev",
        "target_seconds": args.target_seconds,
        "cta_keyword": keyword,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "initialized",
    }
    manifest = {"slug": slug, "items": []}
    shot_plan = {
        "emphasis": [],
        "caption_corrections": {},
        "shots": [],
    }

    write_new(
        engine / f"jobs/{slug}/brief.json",
        json.dumps(brief, indent=2, ensure_ascii=False) + "\n",
    )
    write_new(
        engine / f"jobs/{slug}/giveaway.md",
        f"# {args.topic}\n\nResource promised for comment keyword **{keyword}**.\n",
    )
    write_new(
        engine / f"public/assets/{slug}/manifest.json",
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
    )
    write_new(
        engine / f"jobs/{slug}/shot-plan.json",
        json.dumps(shot_plan, indent=2, ensure_ascii=False) + "\n",
    )
    write_new(
        engine / f"scripts/{slug}.md",
        (
            f"# {args.topic}\n\n"
            "## Final spoken script\n\n"
            "<write the final script here>\n\n"
            "## Beat map\n\n"
            "| VO phrase | Visual | Manifest ID / MG spec |\n"
            "|---|---|---|\n"
        ),
    )
    (engine / f"_sources/assets/{slug}").mkdir(parents=True, exist_ok=True)

    print(f"initialized {slug}")
    print(f"brief: {engine / f'jobs/{slug}/brief.json'}")
    print(f"assets: {engine / f'public/assets/{slug}/'}")


if __name__ == "__main__":
    main()
