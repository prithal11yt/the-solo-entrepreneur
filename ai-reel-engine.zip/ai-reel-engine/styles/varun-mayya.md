# Style pack: varun-mayya (DEFAULT)

Derived from forensic analysis of 11 reels (2026-07-22): contact sheets,
whisper transcripts, demucs stem separation, loudness measurement.

## Script voice
- DEEP script DNA lives in styles/varun-script-playbook.md (hook taxonomy,
  6-act skeleton, connectives, honesty beat, CTA menu, binding rules) —
  the Script Director MUST load it alongside this pack.
- 150-175 words → 45-55s at speed 1.2 (user's preferred pace, 2026-07-23 —
  matches the PUBG reel; ~215 wpm delivered)
- Hook = concrete shock stat/claim, first sentence, no throat-clearing:
  "X just dropped/discovered/revealed…", "X is in federal court right now"
- Short sentences, one idea each. "Anyways," as section pivot.
- Structure: hook → mechanism/context (2-3 beats) → "here's the part almost
  nobody noticed" bridge → biggest reveal → first-person founder take →
  CTA/prediction ("that excuse just got an expiry date") or comment-bait Q.
- Every factual claim gets a receipt; no receipt → facecam line or cut it.

## Scene grammar
- Split hook: footage top / facecam bottom, face on screen by second 2,
  captionBottom 1000. Hook footage must literally depict the hook line.
- Credibility loop: claim → receipt (highlight sweeps synced to VO) → demo →
  take. Receipts on cream or black card, drift + open-zoom near highlight.
- Talking head 10-20% total: hook bottom, bridge, personal take.
- Five b-roll classes: official press footage (credited @channel), screenshot
  receipts, concept motion graphics, AI-generated b-roll, community demo
  clips. Visual change every 2-3s, punch-in on every cut, alternating
  zoomDir, nothing static.
- Type: SF PRO ONLY (user brand rule 2026-07-29 — no serif families).
  SF Pro Display: Black/800 for display headlines, Bold caps for labels,
  Heavy Italic for accent lines; graphics adopt the SUBJECT's brand language
  when possible (Apple white / Kimi dark / Nothing dot-matrix).

## Captions (nick-display — DEFAULT since 2026-07-30, user-mandated)
- captionStyle "nick-display": BIG free-floating SF Pro text, NO pill.
  Connective words SF Pro Italic 700 @66px; emphasis keywords (numbers,
  prices, brands, verbs of value) SF Pro 900 @86px in accent. Words
  accumulate per-word as spoken; phrases hold through pauses (+0.9s cap).
  Deep soft shadow for legibility. Per-scene captionTheme:"dark" over cream
  card fields (ink text, amber #E8A200 accent) — captions must NEVER blend
  with the background. bottom 400 default / per-scene captionBottom.
- Emphasis list = single spoken tokens (match whisper words exactly).
- Legacy chip modes (chip-small/chip-lg) exist as fallback over busy footage
  only.

## Sound (measured: music+SFX layer ≈ -29 LUFS vs -14 mix = 15 LU under voice)
- Music bed ALWAYS, volume-automated 0.07-0.16: full at hook, duck through
  explanation, rise at reveal, up at CTA, fade out last 0.8s.
  Default track: music/bed-184.mp3 from=32 ("Vastness") for tech/serious.
- SFX 6-9 cues max, vols 0.11-0.18: riser under hook + impact on hook type
  land, tech-slide + pops on receipt highlights, one deep impact per major
  reveal, riser tail into CTA. Ordinary cuts are SILENT.
- Hook-vs-voice energy delta +1.5 to +4 dB. Master to -14 LUFS
  (loudnorm I=-14:TP=-1.2:LRA=7); target LRA ≈ 2.5-3.

## ENGINE CAPABILITIES v3 (2026-07-29 — theme-aware, USE THESE)

Beat sheets may set `"style": "varun"` (default). New scene types (wired into
the scene union) + overlays — all pull the varun tokens (cream #f4f0e6,
yellow #FFD84D accent, Fraunces serif) automatically:

- `chart` — brand-styled animated leaderboard/benchmark (staggered bar fills,
  count-ups, accent highlight row + serif badge). REPLACES raw leaderboard/
  table screenshots — never ship a raw chart screenshot again.
- `deviceframe` — screenshot/screen-rec in macOS browser chrome or iPhone
  frame, blurred-self bg fill, push-in. For app/site demos.
- `terminal` — RENDERED macOS terminal (typed commands, ✓/✗ lines, blinking
  prompt). Crisper than real terminal screen-recs and fully directable.
- `annotatezoom` — premium receipt treatment: card + camera-ease to the focus
  region + hand-drawn accent annotations (box/underline/circle/arrow) drawing
  on at cues. Prefer over plain `receipt` when calling out specific phrases.
- overlays on ANY scene: `sprites` (pixel mascot garnish) and `burst` (seeded
  confetti/sparks for milestone beats — max 1 per reel).
- `logoassemble` — brand-logo assembly hook (reference: Google dots→G):
  the logo's SVG paths fly in staggered + spring-settle into the mark, with
  optional count-up label beneath ("15 NEW TOOLS"). Fetch any brand SVG free
  via `node tools/get_logo.mjs <name> [--index n]` (svgl.app; check the match
  list, monochrome fallback = simple-icons); paths embed into the beat, no
  runtime fetch. Use as the pre-hook logo beat or a tool-intro punctuation.
- mechanism beats: `python3 tools/manim_scene.py fanout|pipeline|versus
  --style varun --bg cream|black --out public/assets/<slug>/mg-<name>.mp4` →
  use as a footage scene (see tools/MANIM.md).

## Treatment history (append after each reel; never repeat consecutive)
- indiaai-gpu: split hook, cream receipts w/ highlights, black typecard x2,
  full-bleed footage w/ caps + serif overlays, facecam.
- kimi-india: split hook, cream receipts w/ highlights, black typecard x2,
  full-bleed footage w/ serif overlay, facecam.
- BAN in effect: plain black typecard (user called out repetition) — next
  varun-style reel must use new treatments (type over footage, brand-matched
  cards, stat layouts, type inside receipts).
- record-skill (Anthropic "Record a Skill"): split hook (real Record-a-Skill UI
  top / avatar bottom), SEJ receipt w/ highlight sweep, official Anthropic Cowork
  b-roll (task prompt → autonomous build → analytics result) + the real feature UI
  (menu → dialog → saved) as full-bleed footage w/ caps, cream SERIF typecard +
  wordcascade for the "it broke" turn (NOT black typecard — ban respected),
  facecam take w/ infocard, serif reveal. HeyGen voice (VibeVoice quota out).

## 2026-07-26 — premium bar (from a Varun reference reel, Codex Micro)
Reference showed the pack executed at a higher bar. RULES going forward:
- TITLES = editorial serif that BUILDS line-by-line (label → bold headline →
  italic subtitle), grey→ink colour reveal. Component: HeadlineBuild (Fraunces
  400/600 upright + italic). Reserve blocky condensed CAPS for rare punch only —
  serif is the default title voice now.
- FOOTAGE-FORWARD: lead with the most cinematic official footage FULL-BLEED and
  let it breathe; titles overlay it. Don't lean on cropped UI screenshots or MG
  cards as the backbone.
- SPEC-SHEET MG for "what it is / how it works": dark field, serif title, a few
  label→value rows revealing in sequence, ONE row in brand accent. Component:
  SpecSheet. (Replaces flat black typecards.)
- CAPTIONS: restrained — chip-small (38px) not the 56px sans. Footage does the
  talking; captions support, not shout.
- Match the SUBJECT's brand: Anthropic = cream + clay #d97757 accent + serif.
- record-skill treatment: split serif hook over Anthropic footage, SEJ receipt,
  real Record-a-Skill UI full-bleed w/ serif labels, black SpecSheet, cream serif
  card + wordcascade for the turn, facecam takes, serif CTA.
- nightborne (Blomkamp AI film): split serif hook (clone-army film shot / face),
  film-as-receipt motif — NIGHTBORNE title card, FEATURING cast wall (32 people)
  and A BARLEY STUDIOS PRODUCTION card as black floatcards; dark SpecSheet
  (Seedance 2.0 accent row); Kotaku roast receipt on black; serif-over-footage
  reveals (red cockpit "generated", night helis "a test", action "workstation");
  cream serif wordcascade (a crew/a location/months); wired-face finale.
  HeyGen voice. Premium serif register throughout.
- kimi-k3 (why it's viral + what people built): VibeVoice audio (clone) driving
  HeyGen avatar. Serif hook over a real Kimi 3D-world build; LMArena #1 leaderboard
  receipt; NEW XPost component = faithful credited tweet cards (real @handle + text
  + a giant serif STAT: "2 prompts" @kirillk_web3, "< $1" @soya_da_yoot, "27 min"
  @Fried_rice) over darkened real build footage; benchmark SpecSheet (Kimi K3
  9.5·3¢ accent vs Fable 5 7.5·38¢) attributed @CommandCodeAI; model-access footage
  for "open weights"; serif reveal. Honesty rule: card text = real claim, credited;
  never present other footage AS a specific person's exact build.
- kimi-k3 FEEDBACK (v1→v2): "why show text tweets? show what's BUILT." + "screens
  don't make sense." ROOT: I wrote the VO around 3 named X demos I had no footage
  of, so I fell back to messy tweet screen-grabs (X sidebar visible) + text cards.
  FIX: rewrote the VO to feature builds I had CLEAN footage of, regenerated
  VibeVoice+avatar, went full-bleed on real builds (3D world, FPS, Blender models
  showing Kimi $0.20 vs Fable $3.23), clean #1 leaderboard, benchmark SpecSheet.
  RULE: never script a claim you can't SHOW; footage-first, then write to it.
  Crop OUT app chrome (browser tabs, X sidebar) — a stray tab reads as a mistake.
- emergent (Bengaluru $130M unicorn + India talent): split serif hook (golden-hour
  Bengaluru drone / face, "BENGALURU -> $130,000,000 -> not San Francisco" build);
  emergent.sh live homepage receipt (tagline highlight); zoomed real prompt-box
  floatcard; Emergent's own mascot-agents promo full-bleed; NEW treatment = CNBC-TV18
  TV-graphic floatcards as proof ($1.5Bn Up-5x, 12M apps/70% bullets, production-ready
  bullet, founder Mukund Jha full-frame for "the building is happening here");
  TechCrunch green-hero receipt; FPJ 16%-talent receipt (composed clean card);
  India SpecSheet w/ units over blurred blr footage (16% accent); investor infocard
  on honesty beat; serif CTA over Bengaluru dusk ("quietly dissolving under your
  feet"). VibeVoice audio. No black typecard.
- model-wave (7 models / 7 days release week + Opus 5): split serif hook over
  Kimi 3D-world build; digitalapplied dark editorial receipt (headline zoom +
  composed clean stat-row crops for 5/7 and 3-vendor-claim cards); Kimi dark
  brand card AS spec footage; caps/serif spec overlay over FPS build footage;
  NEW TimelineCascade component (dated brand release cards sliding onto a
  vertical rail — Qwen's 72-hour triple); statcard price bars (TTS ⅓ ElevenLabs,
  Gemini $9→$7.50); Anthropic cream receipt w/ "half the price" highlight; dark
  SpecSheet w/ clay accent + SOTA badge over Anthropic ink-blot film; facecam
  act-break pops; serif CTA over Anthropic grid film. VibeVoice. SpecSheet
  hard-coded WINNER chip replaced by per-row optional `badge`.
- grok-voice (xAI Voice Agent Builder): split serif hook (number provisioning
  top / face), official @Grok launch-video clips as FRAMED cards (floatcard
  cream: create/number/wordmark/voices; deviceframe browser x.ai/voice:
  typing/kb/refund — framed-UI rule enforced, zero full-bleed UI crops), NEW
  manim pipeline floatcard (4-meter old stack), NEW annotatezoom receipts on
  the official post (underlines on "every hop adds cost", circle on $0.05/min
  + underline $0.01/min), NEW chart scene ($/min all-in: Grok $0.06 ★ vs
  ElevenLabs ~$0.08 vs OpenAI ~$0.10+, sourced), deviceframe scroll of the
  announcement, serif reveal over endcard ("expired July 1st"), facecam pops
  (mech setup, honesty, CTA). HeyGen TTS (VibeVoice quota out). Captured via
  tools/capture.mjs (3x receipts + scroll recording). No black typecard.
- india-claude (India = Claude's #2 market): FIRST varun reel with the giant
  "#2" BrandHook (numeral instead of a brand name) over the real INR pricing
  page; TechCrunch green hero card as an annotatezoom receipt (underline on
  "biggest market after the US"); the 5.8% body-quote receipt (circle on the
  number + underline on "second-largest market"); NEW chart use for a social
  stat (ADP daily-AI-use: India 41% highlighted vs Nigeria 39 / Vietnam 36 /
  global 20); Anthropic INR pricing tiers zoomed with a circle on ₹2,000; 4K
  Bengaluru aerials (clouds/metro/dense city/sunset/L&T corridor) carrying the
  "we were downstream" personal beats; closer on an illuminated Indian flag at
  night. 25 scenes / 46s — zero pacing violations. VibeVoice with one sentence
  surgically cut (ChatGPT/OpenAI pronunciation flub, quota exhausted).
- kleo (Cameron Trew nerve story): FIRST reel through the Scout->Director
  pipeline — manifest written + every beat bound before scripting, zero
  missing-footage scramble. Absurd-image hook (33rd-floor flat -> childhood
  bedroom) over Canary Wharf drone + face; $62k Indie Hackers receipt; real Kleo
  app footage (credited @Kleo); "60,000 users -> cease & desist" cream cascade;
  Sold-out SpecSheet w/ column units ($59/500/4 days); honesty beat corrected the
  user's "solo" premise -> "he wasn't solo, 480k followers, one engineer" black
  cascade + infocard; "the tools got cheap / the nerve never did" serif over dusk
  London; VibeVoice audio. Emotional/founder story, not a product launch.
